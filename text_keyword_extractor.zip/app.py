from flask import Flask, request, jsonify
from flask_cors import CORS
import nltk
import os
import re
import string
from nltk.corpus import stopwords, words
from nltk.tokenize import WordPunctTokenizer
import easyocr
import yake
from werkzeug.utils import secure_filename
from textblob import TextBlob
from deep_translator import GoogleTranslator

# Download required NLTK data
nltk.download('stopwords')
nltk.download('words')

# Initialize resources
english_words = set(w.lower() for w in words.words())
stop_words = set(stopwords.words('english'))
tokenizer = WordPunctTokenizer()

# Flask app setup
app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# EasyOCR reader (English + Hindi)
reader = easyocr.Reader(['en', 'hi'])

# --- Utility Functions ---

def clean_text(text):
    text = text.lower()
    text = re.sub(r'\d+', '', text)
    text = re.sub(r'[^\w\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def is_valid_word(word):
    return len(word) > 2 and word.isalpha() and word in english_words

def is_valid_phrase(phrase):
    words = phrase.split()
    return len(words) == 2 and all(is_valid_word(w) for w in words)

def extract_keywords(text, n=1, top=30):
    kw_extractor = yake.KeywordExtractor(lan="en", n=n, dedupLim=0.9, top=top)
    raw_keywords = kw_extractor.extract_keywords(text)
    return [kw for kw, _ in raw_keywords]

def spell_correct_text(text):
    try:
        return str(TextBlob(text).correct())
    except Exception as e:
        print("Spell correction failed:", e)
        return text

def translate_hindi_to_english(text):
    try:
        return GoogleTranslator(source='auto', target='en').translate(text)
    except Exception as e:
        print("Translation error:", e)
        return text

def is_mostly_non_english(text, threshold=0.5):
    english_count = sum(1 for word in text.split() if word.lower() in english_words)
    total_words = len(text.split())
    return english_count / total_words < threshold if total_words else False

def fix_common_ocr_errors(text):
    text = text.replace("lst", "1st")
    text = text.replace("O", "0")
    devanagari_numerals = {
        '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
        '५': '5', '६': '6', '७': '7', '८': '8', '९': '9'
    }
    for dev, eng in devanagari_numerals.items():
        text = text.replace(dev, eng)
    return text

def filter_distinct_phrases(phrases):
    used_words = set()
    distinct_phrases = []
    for phrase in phrases:
        words = phrase.split()
        if all(w not in used_words for w in words):
            distinct_phrases.append([phrase])
            used_words.update(words)
    return distinct_phrases

# --- Main Route ---

@app.route('/extract', methods=['POST'])
def extract_text_and_keywords():
    if 'image' not in request.files:
        return jsonify({"message": "No image file found"}), 400

    file = request.files['image']
    if file.filename == '':
        return jsonify({"message": "No image file found"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    # OCR text extraction
    results = reader.readtext(filepath)
    results = sorted(results, key=lambda x: x[0][0][1])  # Sort by vertical order
    ocr_texts = [text for (_, text, _) in results]
    extracted_text = " ".join(ocr_texts)

    # Fix common OCR errors and Hindi numerals
    extracted_text = fix_common_ocr_errors(extracted_text)

    # Translate if mostly non-English
    if is_mostly_non_english(extracted_text):
        extracted_text = translate_hindi_to_english(extracted_text)

    # Clean and correct
    cleaned_text = clean_text(extracted_text)
    spell_corrected_text = spell_correct_text(cleaned_text)

    # Tokenize and filter
    tokens = tokenizer.tokenize(spell_corrected_text)
    filtered_tokens = [word for word in tokens if word.lower() not in stop_words and is_valid_word(word.lower())]
    filtered_text = ' '.join(filtered_tokens)

    # Keyword extraction
    single_keywords = extract_keywords(filtered_text, n=1, top=30)
    single_keywords_cleaned = [[kw] for kw in single_keywords if is_valid_word(kw)]

    double_keywords = extract_keywords(filtered_text, n=2, top=40)
    double_keywords_valid = [kw for kw in double_keywords if is_valid_phrase(kw)]
    double_keywords_cleaned = filter_distinct_phrases(double_keywords_valid)

    triple_keywords = extract_keywords(filtered_text, n=3, top=50)
    triple_keywords_valid = [kw for kw in triple_keywords if len(kw.split()) == 3 and all(is_valid_word(w) for w in kw.split())]
    triple_keywords_cleaned = filter_distinct_phrases(triple_keywords_valid)

    return jsonify({
        'text': extracted_text,
        'keywords_1': single_keywords_cleaned,
        'keywords_2': double_keywords_cleaned,
        'keywords_3': triple_keywords_cleaned 
    })

if __name__ == '__main__':
    app.run(debug=True)

